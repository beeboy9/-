# Install Python 3 before using:
# cmd: brew install python3 

python3 -m http.server 8000